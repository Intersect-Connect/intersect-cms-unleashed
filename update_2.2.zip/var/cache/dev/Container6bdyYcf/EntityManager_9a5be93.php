<?php

namespace Container6bdyYcf;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder75472 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerb7609 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesf99f5 = [
        
    ];

    public function getConnection()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getConnection', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getMetadataFactory', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getExpressionBuilder', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'beginTransaction', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getCache', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getCache();
    }

    public function transactional($func)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'transactional', array('func' => $func), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->transactional($func);
    }

    public function commit()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'commit', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->commit();
    }

    public function rollback()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'rollback', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getClassMetadata', array('className' => $className), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'createQuery', array('dql' => $dql), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'createNamedQuery', array('name' => $name), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'createQueryBuilder', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'flush', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'clear', array('entityName' => $entityName), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->clear($entityName);
    }

    public function close()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'close', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->close();
    }

    public function persist($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'persist', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'remove', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'refresh', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'detach', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'merge', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getRepository', array('entityName' => $entityName), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'contains', array('entity' => $entity), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getEventManager', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getConfiguration', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'isOpen', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getUnitOfWork', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getProxyFactory', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'initializeObject', array('obj' => $obj), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'getFilters', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'isFiltersStateClean', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'hasFilters', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return $this->valueHolder75472->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerb7609 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder75472) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder75472 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder75472->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__get', ['name' => $name], $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        if (isset(self::$publicPropertiesf99f5[$name])) {
            return $this->valueHolder75472->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder75472;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder75472;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder75472;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder75472;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__isset', array('name' => $name), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder75472;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder75472;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__unset', array('name' => $name), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder75472;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder75472;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__clone', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        $this->valueHolder75472 = clone $this->valueHolder75472;
    }

    public function __sleep()
    {
        $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, '__sleep', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;

        return array('valueHolder75472');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerb7609 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerb7609;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerb7609 && ($this->initializerb7609->__invoke($valueHolder75472, $this, 'initializeProxy', array(), $this->initializerb7609) || 1) && $this->valueHolder75472 = $valueHolder75472;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder75472;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder75472;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
